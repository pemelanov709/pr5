﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR52
{

    interface IFilter
    {
        string Execute(string textLine);
    }


    class DigitFilter : IFilter
    {
        public string Execute(string textline)
        {

            return string.Concat(textline.Split("1234567890".ToCharArray(), StringSplitOptions.RemoveEmptyEntries));
        }
    }


    class LetterFilter : IFilter
    {
       public string Execute(string textline)
        {

            return string.Concat(textline.Split("АаБбВвГгДдЕеЁёЖжЗзИиЙйКкЛлМмНнОоПпРрСсТтУуФфХхЦцЧчШшЩщЪъЫыЬьЭэЮюЯяAaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz"
                .ToCharArray(), StringSplitOptions.RemoveEmptyEntries));
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            IFilter digfilter = new DigitFilter();
            IFilter letterfilter = new LetterFilter();


            string outString;


            Console.Write("Удаление букв/чисел" +
                "\nВыберите действие (Б(буквы)/Ч(числа)): ");

            //Вввод выбора
            char answ = char.Parse(Console.ReadLine());

            //Ввод
            Console.Write("Введите вашу строку: ");
            string inString = Console.ReadLine();

            //Выбор и удаление символов
            if (answ == 'Б' | answ == 'б')
                outString = letterfilter.Execute(inString);
            else if (answ == 'Ч' | answ == 'ч')
                outString = digfilter.Execute(inString);
            else
                outString = "Ошибка, в выборе";

            //Вывод
            Console.WriteLine(outString);
            Console.ReadKey();
        }
    }
}

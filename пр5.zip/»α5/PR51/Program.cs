﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR51
{

    interface IHello
    {
        void SayHello();
    }

    class EngHello : IHello
    {
        public void SayHello()
        {
            Console.WriteLine("Hello! Im from Britain");
        }
    }

    class GerHallo : IHello
    {
        public void SayHello()
        {
            Console.WriteLine("Hallo! Ich komme aus Deutschland");
        }
    }

    class USAHi : IHello
    {
        public void SayHello()
        {
            Console.WriteLine("Hi! Im from USA");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            List<IHello> interNatHello = new List<IHello>();

            interNatHello.Add(new EngHello());
            interNatHello.Add(new GerHallo());
            interNatHello.Add(new USAHi());

            foreach(IHello interhello in interNatHello)
            {
                interhello.SayHello();
            }

            Console.ReadKey();
        }
    }
}

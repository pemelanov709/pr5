﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR5
{
    interface IAnimal
    {
        void Voice();
    }

    class Dog : IAnimal
    {
        public void Voice()
        {
            Console.WriteLine("Гав!");
        }
    }

    class Cat : IAnimal
    {
        public void Voice()
        {
            Console.WriteLine("Мяу!");
        }
    }

    class svin : IAnimal
    {
        public void Voice()
        {
            Console.WriteLine("хрю!");
        }
    }
    class golub : IAnimal
    {
        public void Voice()
        {
            Console.WriteLine("курлык!");
        }
    }

    class Owl :  IAnimal
    {
        private int GetCurrentTime()
        {
            return Convert.ToInt32(File.ReadAllText("current_time.txt"));
        }

        public void Voice()
        {
            int currentTime = GetCurrentTime();

            if((currentTime >=8) && (currentTime <=21))
            {
                Console.WriteLine("Тише, я сплю!");
            }
            else
            {
                Console.WriteLine("Ух! Ух! Ух!");
            }
        }
    }

    class Program
    {
        //Статический метод
        static void PetAnimal(IAnimal animal)
        {
            Console.WriteLine("Мы гладим зверушку, а она нам говорит: ");
             animal.Voice();
        }

        static void Main(string[] args)
        {
            //Приветствие пользователя
            Console.WriteLine("Вас приветсвует наш гладильный зоопарк!");

            //Инициализация объектов с интерфейсом и дочерним классом
            Dog tuzik = new Dog();
            PetAnimal(tuzik);

            Cat boris = new Cat();
            PetAnimal(boris);

            IAnimal hewdig = new Owl();
            PetAnimal(hewdig);

            IAnimal golub = new golub();
            PetAnimal(golub);

            IAnimal svin = new svin();
            PetAnimal(svin);

            Console.ReadKey(true);
        }
    }
}

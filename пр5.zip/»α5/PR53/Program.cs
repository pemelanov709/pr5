﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR53
{

    interface IShare
    {
        void Draw(int size);
    }

    //Вертикаль
    class VerticalLine : IShare
    {
        public void Draw(int size)
        {
            for(int i=0; i < size; i++)
            Console.Write("|");
        }
    }

    //Горизонталь
    class HorizontalLine : IShare
    {
        public void Draw(int size)
        {
            for (int i = 0; i < size; i++)
                Console.WriteLine("-");
        }
    }

    //Квадрат
    class Square : IShare
    {
       public void Draw(int size)
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 1; j < size; j++)
                    Console.Write("#");
                Console.WriteLine("#");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IShare square = new Square();
            IShare vertLine = new VerticalLine();
            IShare horline = new HorizontalLine();

            //Приветствие пользователя
            Console.Write("Отрисовка вертикальных/горизонтальных линий , квадрата" +
                "\nВыберите фигуру (К(квадрат)/Г(горизонталь)/В(вертикаль)): ");


            char answ = char.Parse(Console.ReadLine());

            //размер
            Console.Write("Введите её размер: ");
            int size = int.Parse(Console.ReadLine());

            //Отступ
            Console.WriteLine("");

            //Отрисовка
            if (answ == 'К' | answ == 'к')
                square.Draw(size);
            else if (answ == 'Г' | answ == 'г')
                horline.Draw(size);
            else if (answ == 'В' | answ == 'в')
                vertLine.Draw(size);
            else
                Console.WriteLine("ОШИБКА, ВЫ ОШИБЛИСЬ ВЫБОРОМ");

            Console.ReadLine();
        }

    }
}
